def do_magic(thing):
    return thing + " is now magical!"
